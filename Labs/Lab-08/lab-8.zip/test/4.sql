.eqp on
.headers on

select s_name
from supplier
where s_acctbal > 8000;
